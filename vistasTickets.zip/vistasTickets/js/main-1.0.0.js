
async function CargarVista(nombreVista) {
    
    const contPrincipal = document.getElementById("contenidoPrincipal");

    try {
        const html = await fetch(`vistas/${nombreVista}.html`)
        .then(r => r.text())
        contPrincipal.innerHTML = html;

        const script = document.createElement("script");
        script.src = `./js/${nombreVista}.js`;
        script.type = "text/javascript";
        document.body.appendChild(script);
    } catch (err) {
        contPrincipal.innerHTML = "<p>Error al cargar la vista.</p>";
        console.error("Error al cargar vista:", err);
    }
}

/* window.onload = () => CargarVista(nombreVista); */